create definer = glosuser@`%` view v_contribuciones_pedimento as
select `con`.`FK_DataStage`                                   AS `FK_DataStage`,
       `con`.`Patente`                                        AS `Patente`,
       `con`.`Pedimento`                                      AS `Pedimento`,
       `con`.`SeccionAduanera`                                AS `SeccionAduanera`,
       `gds`.`FK01_Cliente`                                   AS `FK01_Cliente`,
       `dg`.`FechaPagoReal`                                   AS `FechaPagoReal`,
       coalesce(`dif`.`Origen`, `con`.`Origen`)               AS `Origen`,
       `con`.`ClaveContribucion`                              AS `ClaveContribucion`,
       (case `dg`.`TipoPedimento`
            when 1 then coalesce(`con`.`ImportePago`, 0)
            when 2 then coalesce(`dif`.`ImportePago`, 0) end) AS `ImportePago`
from ((((select `inner_a`.`FK_DataStage`      AS `FK_DataStage`,
                `inner_a`.`Patente`           AS `Patente`,
                `inner_a`.`Pedimento`         AS `Pedimento`,
                `inner_a`.`SeccionAduanera`   AS `SeccionAduanera`,
                `inner_a`.`ClaveContribucion` AS `ClaveContribucion`,
                `inner_a`.`Origen`            AS `Origen`,
                `inner_a`.`ImportePago`       AS `ImportePago`
         from (select `cp`.`FK_DataStage`      AS `FK_DataStage`,
                      `cp`.`Patente`           AS `Patente`,
                      `cp`.`Pedimento`         AS `Pedimento`,
                      `cp`.`SeccionAduanera`   AS `SeccionAduanera`,
                      `cp`.`ClaveContribucion` AS `ClaveContribucion`,
                      557                      AS `Origen`,
                      sum(`cp`.`ImportePago`)  AS `ImportePago`
               from `glosanet`.`contribuciones_partida_557` `cp`
               where (`cp`.`Pedimento` <> 0)
               group by `cp`.`FK_DataStage`, `cp`.`Patente`, `cp`.`Pedimento`, `cp`.`SeccionAduanera`,
                        `cp`.`ClaveContribucion`
               union all
               select `cp`.`FK_DataStage`      AS `FK_DataStage`,
                      `cp`.`Patente`           AS `Patente`,
                      `cp`.`Pedimento`         AS `Pedimento`,
                      `cp`.`SeccionAduanera`   AS `SeccionAduanera`,
                      `cp`.`ClaveContribucion` AS `ClaveContribucion`,
                      510                      AS `Origen`,
                      sum(`cp`.`ImportePago`)  AS `ImportePago`
               from `glosanet`.`contribuciones_pedimento_510` `cp`
               where (`cp`.`Pedimento` <> 0)
               group by `cp`.`FK_DataStage`, `cp`.`Patente`, `cp`.`Pedimento`, `cp`.`SeccionAduanera`,
                        `cp`.`ClaveContribucion`
               union all
               select `dcp`.`FK_DataStage`      AS `FK_DataStage`,
                      `dcp`.`Patente`           AS `Patente`,
                      `dcp`.`Pedimento`         AS `Pedimento`,
                      `dcp`.`SeccionAduanera`   AS `SeccionAduanera`,
                      `dcp`.`ClaveContribucion` AS `ClaveContribucion`,
                      702                       AS `Origen`,
                      0                         AS `ImportePago`
               from `glosanet`.`diferencias_contribuciones_pedimento_702` `dcp`
               where (`dcp`.`ClaveContribucion` not in (1, 3, 6))
               group by `dcp`.`FK_DataStage`, `dcp`.`Patente`, `dcp`.`Pedimento`, `dcp`.`SeccionAduanera`,
                        `dcp`.`ClaveContribucion`) `inner_a`) `con` left join (select `dcp`.`FK_DataStage`      AS `FK_DataStage`,
                                                                                      `dcp`.`Patente`           AS `Patente`,
                                                                                      `dcp`.`Pedimento`         AS `Pedimento`,
                                                                                      `dcp`.`SeccionAduanera`   AS `SeccionAduanera`,
                                                                                      `dcp`.`ClaveContribucion` AS `ClaveContribucion`,
                                                                                      702                       AS `Origen`,
                                                                                      sum(`dcp`.`ImportePago`)  AS `ImportePago`
                                                                               from `glosanet`.`diferencias_contribuciones_pedimento_702` `dcp`
                                                                               where (`dcp`.`Pedimento` <> 0)
                                                                               group by `dcp`.`FK_DataStage`,
                                                                                        `dcp`.`Patente`,
                                                                                        `dcp`.`Pedimento`,
                                                                                        `dcp`.`SeccionAduanera`,
                                                                                        `dcp`.`ClaveContribucion`) `dif`
        on (((`dif`.`FK_DataStage` = `con`.`FK_DataStage`) and (`dif`.`Patente` = `con`.`Patente`) and
             (`dif`.`Pedimento` = `con`.`Pedimento`) and (`dif`.`SeccionAduanera` = `con`.`SeccionAduanera`) and
             (`dif`.`ClaveContribucion` = `con`.`ClaveContribucion`)))) join `glosanet`.`datos_generales_501` `dg`
       on (((`dg`.`FK_DataStage` = `con`.`FK_DataStage`) and (`dg`.`Patente` = `con`.`Patente`) and
            (`dg`.`Pedimento` = `con`.`Pedimento`) and
            (`con`.`SeccionAduanera` = `dg`.`SeccionAduanera`)))) join `glosanet`.`gn_datastage` `gds`
      on ((`gds`.`PK_DataStage` = `dg`.`FK_DataStage`)));

