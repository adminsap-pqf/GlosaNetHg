import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { HttpModule } from "@angular/http";
import { DropListComponent } from "./drop-list.component";
import { SearchBarModule } from "../search-bar/search-bar.module";
import { SlimScroll } from "angular-io-slimscroll";
import { RadioButtonModule } from "../radio-button/radio-button.module";


@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    SearchBarModule,
    RadioButtonModule
  ],
  declarations: [
    DropListComponent,
    SlimScroll
  ],
  exports:[
    DropListComponent
  ]
}) 
export class DropListModule { }