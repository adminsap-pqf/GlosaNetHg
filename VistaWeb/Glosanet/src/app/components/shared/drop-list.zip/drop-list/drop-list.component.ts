import { Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer, SimpleChanges } from '@angular/core';
import { SimpleChange } from '@angular/core/src/change_detection/change_detection_util';

@Component({
  selector: 'gn-drop-list',
  templateUrl: './drop-list.component.html',
  styleUrls: ['./drop-list.component.scss']
})
export class DropListComponent implements OnInit {

  @Output() valueDropList: EventEmitter<any> = new EventEmitter();
  @Input() items: any;
  @Input() isSearch: boolean = true;
  @Input() isCategory: boolean = false;
  @Input() size: String = '';
  @Input() align: String = '';
  @Input() itemSelect: any;
  @Input() widthContent: any = '100%';
  @Input() marginLeftContent: any = '0px';
  @Input() tooltip: boolean = false;

  @Input() lineaColor:string = '';

  @Input() color:String = '';
  @Input() fontSize:String = '';

  @Input() fontWeight: string = '';
  @Input() fontFamily:string = '';

  @Input() radio: boolean = false;

  @Input() flecha: boolean = true;

  //@Input() placeH: string = '';

  clickListener: Function;
  showDropList: boolean;
  dropListClass: string = 'dropList';
  title: string;
  placeholder: any = 'Search';
  searchTerm: string = null;
  arrayAux: any = [];
  search: any = [];
  resetSearch: boolean;

  radioArray:boolean[];

  title1: string = 'Todos los Eventos';
  title2: string = 'Todos';

  constructor(private renderer: Renderer, private elementRef: ElementRef) {
    this.clickListener = renderer.listenGlobal(
      'document',
      'click',
      (event: MouseEvent) => this.handleGlobalClick(event)
    );
  }

  ngOnInit() {
    this.showDropList = false;
    //this.title = this.placeH;
    //this.dropListClass = 'dropList';
    //this.fillArrayAux();
  }

  ngOnChanges(changes: SimpleChanges){
    //console.log(changes);
    if (changes.items != undefined){
      //console.log('entra');
      this.fillArrayAux();
    }
    if(changes.itemSelect !== undefined){
      console.log(changes.itemSelect);
      this.dropListClass = 'dropListSelect';
      if(changes.itemSelect.currentValue !== undefined && !changes.firstChange){
        this.selectItem(this.itemSelect, 0);
      }
    }
  }

  /* Escucha el evento click globalmente */
  handleGlobalClick(event: MouseEvent): void {
    const withinElement = this.elementRef.nativeElement.contains(event.target);
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.closeDropList();
    }
  }
  /* Cierra el drop list */
  closeDropList(): void {
    this.showDropList = false;
  }

  /* Abre el drop list */
  openDropList($event): void {
    $event.stopPropagation();
    this.showDropList = !this.showDropList;
  }

  /* Selecciona opcion del drop list */
  selectItem(item: any,index, $event?): void {
    $event !== undefined ? $event.stopPropagation() :null;
    console.log(item);
    if(!this.radio){
      this.title = item.nombre;
    }else{
      if(item.seccion == 1){
        this.title1 = item.nombre;
      }else{
        this.title2 = item.nombre
      }
    }

    console.log(this.title);
    console.log(this.title1);
    console.log(this.title2);

    if(!this.radio){
      this.closeDropList();
    }
    this.resetSearch = !this.resetSearch;
    this.dropListClass = 'dropListSelect';
    this.valueDropList.emit(item);

    console.log(index);
    let seccion = item.seccion;
    let i = 0;
    if(this.radio){
      for(let item of this.arrayAux){
        if(seccion == item.seccion){
          this.radioArray[i] = false;
        }
        i++;
      }
      this.radioArray[index] = true;
      console.log(this.radioArray);
    }
    console.log(this.title);
    console.log(this.radio)
    
    //this.fillArrayAux();
  }

  /* Busqueda de search bar */
  changeSearchTerm($event) {
    this.arrayAux = [];
    for (let item of this.items) {
      this.arrayAux.push(item);
    }
    if ($event !== '') {
      this.search = [];
      for (let item of this.arrayAux) {
        if (item.nombre.toLowerCase().indexOf($event.toLowerCase()) !== -1) {
          this.search.push(item);
        }
      }
      if (this.search.length > 0) {
        this.arrayAux = [];
        for (let item of this.search) {
          this.arrayAux.push(item);
        }
      }else {
        this.arrayAux = [];
      }
    }else {
      this.arrayAux = [];
      for (let item of this.items) {
        this.arrayAux.push(item);
      }
    }
  }
  /* Llenar el arreglo auxiliar */
  fillArrayAux() {
    this.arrayAux = [];
    for (let item of this.items){
      this.arrayAux.push(item);
    }

    this.radioArray = new Array<boolean>(this.arrayAux.length).fill(false);
    console.log(this.radioArray);
    this.radioArray[4] = true;
    this.radioArray[6] = true;
  }

  ngOnDestroy() {
    this.clickListener();
  }

}
